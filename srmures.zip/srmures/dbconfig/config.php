<?php
//Change password accordingly and import the database devpoint
$con=mysqli_connect("localhost","root","5638");
mysqli_select_db($con,"devpoint");
?>
