<?php

require('dbconfig/config.php');
extract($_POST);
echo $user;

if($user=="faculty")
{
  $q="select * from tbl_faculty where email='$email' and password='$password'";
  if(mysqli_num_rows(mysqli_query($con,$q))>0)
   { session_start();
     $_SESSION["faculty"]=$email;
     $_SESSION['start']=time();
	   $_SESSION['expire']=$_SESSION['start']+(1000*1);
     header('location:faculty/home');
   }
   else header('location:login?id=1');
}
if($user=="hr")
{
  $q="select * from tbl_hr where username='$email' and password='$password'";

  if(mysqli_num_rows(mysqli_query($con,$q))>0)
   { session_start();
     $_SESSION["hr"]=$email;
     $_SESSION['start']=time();
	   $_SESSION['expire']=$_SESSION['start']+(1000*1);
     header('location:hr/home');
     echo $q;
   }
   else echo header('location:login?id=1');
}
?>
