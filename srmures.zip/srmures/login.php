<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Log IN</title>
    <link rel="stylesheet" href="css/nav.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,500" rel="stylesheet">
    <link rel="stylesheet" href="css/loader.css"/>
    <link rel="stylesheet" href="css/form.css">
    <link rel="stylesheet" href="css/foot.css">
    <script type="text/javascript" src="js/load.js"></script>



  </head>
    <body onload="myFunction()" id="demo" style="margin:0;background: #202340;" oncontextmenu="return false;">
    <div id="loader">
        <h1>SRMU Research and Placement Portal</h1>
        <div class="cube-wrapper">
            <div class="cube-folding">
                <span class="leaf1"></span>
                <span class="leaf2"></span>
                <span class="leaf3"></span>
                <span class="leaf4"></span>
              </div>
              <span class="loading" data-name="Loading">Login</span>
        </div>


    </div>

<div style="display:none;" id="myDiv">
    <div class="tnav">
       <div class="tnavtop">

           <a style="color:white;" href="../srmures/">
             <img src="images/dp-logo.png" />
           <span>SRMU Research and Placement Portal</span>
         </a>
           <a href="#" id="right" onclick="log()">Login / Sign Up</a>

       </div>
       <div id="log" style="display:none;">
         <span>Faculty</span>
         <a href="login">
         <button type="button">Login</button>
         </a>
         
         <br><br>

        <span>HR</span>
          <a href="login">
          <button type="button">Login</button>
          </a>
          
       </div>

       <div class="tnavdown">
         <div class="adark">
           <div class="dark">

           </div>
           <span>Quick Links:</span>
         </div>

         <div class="links">
         <a href="index">Homepage</a>
         <a href="#">Placement Portal</a>
           <a href="https://srmu.ac.in">SRMU Website</a>
           <a href="login">HR Login</a>
           <a href="login">Faculties Login</a>
           <a href="#abt">Contact us</a>


         </div>
       </div>
    </div>
    <div class="page">
      <?php
      error_reporting(0);
      $id=$_REQUEST['id'];
      if($id==1)
      {
        echo "<br><br><span>Wrong Email/Password<br><br></span>";
      }
      if($id==2)
      {
        echo "<br><br><span>Session Expire !!<br></span>";
      }
      if($id==3)
      {
        echo "<br><br><span>Logout Successfully !!<br></span>";
      }
       ?>
      <form class="form" action="logcode" method="post">
        <span>Login</span><br>
        <select class="dept" name="user" required>
          <option value="">--Login As--</option>
          <option value="hr">HR</option>
          <option value="faculty">Faculty</option>
        </select><br>

        <input class="in" type="email" name="email" placeholder="Enter Your Email/Roll No." required/><br>
        <input class="in" type="password" name="password" placeholder="Enter Password" required/><br>
        <input type="submit" style="cursor:pointer;" name="submit" value="Login">
      </form>


    </div>

</div>
<div class="footer">
    <p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
</div>
<script type="text/javascript">
  function log() {
    var div = document.getElementById('log');
        var status=div.style.display;
        if(status=="none")
        {
          div.style.display="block";
        }
        else
        {
          div.style.display="none";
        }
  }
</script>
  </body>
</html>
