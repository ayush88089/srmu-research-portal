<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
$valid=$_REQUEST['upload'];

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Faculty</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/flip.css">
    <link rel="stylesheet" href="../css/nav.css">
	<link rel="stylesheet" href="../css/foot.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Upright" rel="stylesheet">
    <link rel="stylesheet" href="../css/viewfac.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">



  </head>
    <body>
    

<div>
<div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['hr'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

           </div>
           <span>Quick Links:</span>
         </div>

         <div class="links">
         <a href="home">Homepage</a>
         <a href="addfac">Add Faculty</a>
         <a href="editfac">Edit Faculty</a>
         <a href="reset">Reset Faculty Password</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>


         </div>
       </div>
    </div>
    <div class="table-responsive" style="overflow-x:inherit;">
  <table class="table">
    <thead>
      <tr>
      <th>S.no</th>
              <th>Name</th>
              <th>Department</th>
              <th>Email</th>
              <th>Password</th>
              <th>Area Of Interest</th>
              <th>About</th>
              <th>Degree</th>
              <th>Experience</th>
              <th>Edit</th>
              <th>Delete</th>
      </tr>
    </thead>
    <?php
                            $query="Select * from tbl_faculty";
                            $res=mysqli_query($con,$query);
                            $s_no=1;
                            while($row=mysqli_fetch_assoc($res))
                            {
	?>
    <tbody>
      <tr>
      <td scope="col"><?php echo $s_no; ?></td>
              <td scope="col"><?php echo $row['name']; ?></td>
              <td scope="col"><?php echo $row['department']; ?></td>
              <td scope="col"><?php echo $row['email']; ?></td>
              <td scope="col"><?php echo $row['password']; ?></td>
              <td scope="col"><?php echo $row['aoi']; ?></td>
              <td scope="col"><?php echo $row['about']; ?></td>
              <td scope="col"><?php echo $row['degree']; ?></td>
              <td scope="col"><?php echo $row['experience']; ?></td>
              
              <td scope="col"><a href="updatefac?fid=<?php echo $row['fid'];?>" >Edit</a></td>
              <td scope="col"><a href="deletefac?fid=<?php echo $row['fid'];?>">Delete</a></td>
      </tr>
      <?php
                $s_no++;
		}
	    ?>
      
    </tbody>
  </table>
</div>
<div class="footer">
    <p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
</div>

  </body>
</html>
