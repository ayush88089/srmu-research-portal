<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
$valid=$_REQUEST['upload'];

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin</title>
    <link rel="stylesheet" href="../css/nav.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,500" rel="stylesheet">
    <link rel="stylesheet" href="../css/loader.css"/>
    <link rel="stylesheet" href="../css/form.css">
    <link rel="stylesheet" href="../css/foot.css">



  </head>
    <body id="demo" style="margin:0;background: whitesmoke;">
    

<div>
<div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['hr'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

           </div>
           <span>Quick Links:</span>
         </div>

         <div class="links">
         <a href="home">Homepage</a>
         <a href="addfac">Add Faculty</a>
         <a href="editfac">Edit Faculty</a>
         <a href="reset">Reset Faculty Password</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>


         </div>
       </div>
    </div>
    <div class="page">

    <form class="form" action="update" method="post" >
        <?php
        error_reporting(0);
        $msg=$_REQUEST['msg'];
        $delete=$_REQUEST['delete'];
        if($msg==1)
        {
          echo "<br><span>Update Successful !!</span><br>";
        }
        if($msg==2||$delete==2)
        {
          echo "<br><span>Error !!</span><br>";
        }
        if($delete==1)
        {
          echo "<br><span>Deletion Successful !!</span><br>";
        }
        $fid=$_REQUEST['fid'];
        $q="Select * from tbl_faculty where fid='$fid'";

        $res=mysqli_query($con,$q);
        if($row=mysqli_fetch_array($res,MYSQL_BOTH))
        {
        ?>
        <input type="hidden" name="fid" value="<?php echo $fid?>">
        <input class="in" type="text" name="name" placeholder="Enter Your name" required value="<?php echo $row['name'];?>"/><br>
        <select class="dept" name="dept" required>
          <option value="" selected disabled>--Select Department--</option>
          <option value="cse">CSE</option>
          <option value="civil">Civil</option>
          <option value="me">Mechanical</option>
          <option value="ece">ECE</option>
          <option value="ee">EE</option>
          <option value="bio">Biotechnology</option>
        </select><br>
        <select class="dept" name="degree" required>
          <option value="" selected disabled>--Select Degree--</option>
          <option value="B.Tech">B.Tech</option>
          <option value="M.tech">M.Tech</option>
          <option value="BCA">BCA</option>
          <option value="MCA">MCA</option>
          <option value="PHD">PHD</option>
          <option value="other">Other</option>
        </select><br>
        <input class="in" type="email" name="email" placeholder="Enter Email" required value="<?php echo $row['email'];?>"/><br>
        
        <input class="in" type="text" name="exp" maxlength="3" placeholder="Enter Work Experience" value="<?php echo $row['experience'];?>" required/><br>
        <br>
        <input class="in" type="text" name="no" maxlength="10" placeholder="Enter Mobile no" required value="<?php echo $row['mobile'];?>"/><br>
        <input class="in" type="text" name="special" placeholder="Area Of Intrest" value="<?php echo $row['aoi'];?>"/><br>
        <textarea class="txt" id="int" name="abt" rows="8" cols="80" placeholder="About Yourself" required><?php echo $row['about'];?></textarea>
        <br>
        <input style="cursor:pointer;" type="submit" name="submit" value="Update">
        <?php
        }
        ?>
      </form>


    </div>

</div>
<div class="footer">
    <p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
</div>

  </body>
</html>
