<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
extract($_POST);
$query="UPDATE `tbl_faculty` SET `password`='123' WHERE `fid`='$employee'";
echo $query;
$run=mysqli_query($con,$query);
if($run)
header("Location:reset?msg=1");
else header("Location:reset?msg=2");
?>
