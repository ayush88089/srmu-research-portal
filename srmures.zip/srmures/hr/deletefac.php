<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
$id=$_REQUEST['fid'];

$a="select photo from tbl_faculty where fid='$id'";
echo $a;
$res=mysqli_query($con,$a);
if($row=mysqli_fetch_assoc($res))
$path="../upload/faculty/".$row['photo'];
echo $path;
unlink($path);
$query="delete from tbl_faculty where fid='$id'";
echo $query;
$run=mysqli_query($con,$query);
if($run)
{
  $quer="delete from tbl_paper where fid='$id'";
  mysqli_query($con,$quer);
  header("Location:updatefac?delete=1");
}
else header("Location:updatefac?delete=2");
?>