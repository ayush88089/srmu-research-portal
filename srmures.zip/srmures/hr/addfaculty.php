<?php
extract($_POST);
session_start();
require('../dbconfig/config.php');
$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
$a="select * from tbl_faculty where email='$email' and mobile='$no'";
$row=mysqli_query($con,$a);
if(mysqli_num_rows($row)==0)
{
//  $photo=$_POST['photo'];
  $file=$_FILES['photo']['name'];
  $file=md5($file);
  //echo $file;
  $size=$_FILES['photo']['size'];
  //echo $size;
  $type=$_FILES['photo']['type'];
//  echo $type;
  $tmp_name=$_FILES['photo']['tmp_name'];
//  echo $tmp_name;
  $location="../upload/faculty/";

$q="INSERT INTO `devpoint`.`tbl_faculty` (`name`, `department`, `email`, `password`, `mobile`, `photo`, `aoi`, `about`,`degree`,`experience`) VALUES ('$name', '$dept', '$email', '$pass', '$no', '$file','$special', '$abt' ,'$degree','$exp')";
echo $q;
if(mysqli_query($con,$q))
{
  move_uploaded_file($tmp_name,$location.$file);
  header("location:addfac?msg=1");
}
else {
  header("location:addfac?msg=2");
}

}
 ?>
