<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
extract($_POST);
$query="UPDATE `tbl_faculty` SET `name`='$name',`experience`='$exp',`department`='$dept',`degree`='$degree',`mobile`='$no',`aoi`='$special',`about`='$abt' WHERE `fid`='$fid'";
echo $query;
$run=mysqli_query($con,$query);
if($run)
header("Location:updatefac?msg=1");
else header("Location:updatefac?msg=2");
?>
