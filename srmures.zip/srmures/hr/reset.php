<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
$valid=$_REQUEST['upload'];

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin</title>
    <link rel="stylesheet" href="../css/nav.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,500" rel="stylesheet">
    <link rel="stylesheet" href="../css/loader.css"/>
    <link rel="stylesheet" href="../css/form.css">
    <link rel="stylesheet" href="../css/foot.css">



  </head>
    <body id="demo" style="margin:0;background: whitesmoke;">
    

<div>
<div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['hr'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

           </div>
           <span>Quick Links:</span>
         </div>

         <div class="links">
         <a href="home">Homepage</a>
         <a href="addfac">Add Faculty</a>
         <a href="editfac">Edit Faculty</a>
         <a href="reset">Reset Faculty Password</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>


         </div>
       </div>
    </div>
    <div class="page">

    <form class="form" action="resetpass" method="post" >
        <?php
        error_reporting(0);
        $msg=$_REQUEST['msg'];
        if($msg==1)
        {
          echo "<br><span>Reset Successful !!</span><br>";
        }
        if($msg==2)
        {
          echo "<br><span>Error !!</span><br>";
        }
        
        $q="Select * from tbl_faculty";

        $res=mysqli_query($con,$q);
        
        ?>
        <select class="dept" name="employee" required>
          <option value="" selected disabled>--Select Faculty Email ID--</option>
          <?php
          while($row=mysqli_fetch_array($res,MYSQL_BOTH))
          {
              ?>
          <option value="<?php echo $row['fid'];?>"><?php echo $row['email'];?></option>
          <?php
        }
        ?>
        </select><br>
        
        
        <input style="cursor:pointer;" type="submit" name="submit" value="Reset">
        
      </form>


    </div>

</div>
<div class="footer">
    <p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
</div>

  </body>
</html>
