<?php
session_start();
require('../dbconfig/config.php');

extract($_POST);
$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
$fid=$_SESSION['hr'];
$password_query="SELECT password FROM tbl_hr WHERE username='$fid'";
$res=mysqli_query($con,$password_query);
while($row=mysqli_fetch_assoc($res))
{   $a=$row['password'];
    if($a==$opass)
    {
        if($npass==$cpass)
        {
            $password_update = "UPDATE `tbl_hr` SET `password`='$npass' WHERE `username`='$fid'";
            $run=mysqli_query($con,$password_update);
            if($run)
            header('Location:change?change=1');
            else header('Location:change?change=3');
        }
        else header('Location:change?change=2');
    }
    else header('Location:change?change=4');
}
?>