<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=5");
}

//echo $_SESSION['faculty'];
if($_SESSION['hr']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <meta charset="utf-8">
    <title>Dashbored</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="../css/dash.css"> -->
    <link rel="stylesheet" href="../css/index.css" type="text/css">
    <link rel="stylesheet" href="../css/flip.css" type="text/css">
    <link rel="stylesheet" href="../css/nav.css" type="text/css">
		<link rel="stylesheet" href="../css/foot.css" type="text/css">
  </head>
  <body>

  <div class="tnav" style="float:none;">
     <div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['hr'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

         </div>
         <span>Quick Links:</span>
       </div>

       <div class="links">
		 <a href="home">Homepage</a>
         <a href="addfac">Add Faculty</a>
         <a href="editfac">Edit Faculty</a>
         <a href="reset">Reset Faculty Password</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>
       </div>
     </div>
  </div>
  
  <div class="content">
		<div class="card">
          <div class="imgbox">
              <img src="../images/add-employee.png" alt="">
          </div>
          <div class="details">
              <a href="addfac">ADD FACULTY</a>
          </div>
    </div>
		
    <div class="card">
          <div class="imgbox">
              <img src="../images/view.png"  alt="">
          </div>
          <div class="details">
              <a href="editfac">EDIT FACULTY</a>
          </div>
    </div>
		
    <div class="card">
          <div class="imgbox">
              <img src="../images/change.png"  alt="">
          </div>
          <div class="details">
              <a href="change">CHANGE PASSWORD</a>
          </div>
    </div>

    <div class="card">
           <div class="imgbox">
              <img src="../images/logout.png"  alt="">
           </div>
           <div class="details">
              <a href="logout">LOGOUT</a>
          </div>
    </div>
  </div>
	<div class="footer">
			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
	</div>
  </body>
</html>
