
 <?php
 session_start();
 require('dbconfig/config.php');
 extract($_POST);
 error_reporting(0);
 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>

     <meta charset="utf-8">
     <title>Search Faculty</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <link rel="stylesheet" href="css/index.css" type="text/css">
     <link rel="stylesheet" href="css/flip.css" type="text/css">
     <link rel="stylesheet" href="css/nav.css" type="text/css">
 	 <link rel="stylesheet" href="css/foot.css" type="text/css">
   </head>
   <body>

   <div class="tnav">
      <div class="tnavtop">
          <img src="images/dp-logo.png" />
          <span>SRMU Research and Placement Portal</span>


      </div>


      <div class="tnavdown">
        <div class="adark">
          <div class="dark">

          </div>
          <span>Quick Links:</span>
        </div>

        <div class="links">
        <a href="index">Homepage</a>
          <a href="#">Placement Portal</a>
           <a href="https://srmu.ac.in">SRMU Website</a>
           <a href="login">HR Login</a>
           <a href="login">Faculties Login</a>
           <a href="#abt">Contact us</a>
        </div>
      </div>
   </div>


<div class="table-responsive" style="float:left;">

    <table class="table table-striped table-responsive">
    <thead>
    <?php 
    if((int)$by<6)
    {  
    ?>
     <tr>
       <th>S.no</th>
       <th>Paper Name</th>
       <th>Author</th>
       <th>Conference</th>
       <th>Year</th>
       <th>Department</th>
     </tr>
     <?php 
     }
     else {
      ?>
      <tr>
        <th>S.no</th>
        <th>Name</th>
        <th>Department</th>
        <th>Email</th>
        <th>Degree</th>
        <th>Experience</th>
        <th>Profile</th>
      </tr>
      <?php 
     }
     ?>

   </thead>
   <tbody>

      <?php
      if($by=='1')
        {   
            $research_query_keyword= "SELECT * FROM tbl_paper WHERE (`name` LIKE '%".$search."%') or (`author` LIKE '%".$search."%' ) or (`confrence` LIKE '%".$search."%') or (`about` LIKE '%".$search."%') or (`keyword` LIKE '%".$search."%')";
            $result_keyword = mysqli_query($con,$research_query_keyword);
            $s_no=1;
            while($row=mysqli_fetch_assoc($result_keyword))
            {
              ?>
              <tr>
              <td><?php echo $s_no; ?></td>
              <td><a href="faculty/upload/faculty/<?php echo $row['path'];?>" target="_blank"><?php echo $row['name']; ?></a></td>
              <td><?php echo $row['author']; ?></td>
              <td><?php echo $row['confrence']; ?></td>
              <td><?php echo $row['year']; ?></td>
              <td><?php echo $row['department']; ?></td>
              </tr>

        <?php
              $s_no++;
            }
        }
        ?>
      <?php
      if($by=='2')
        {   
            $research_query_keyword= "SELECT * FROM tbl_paper WHERE (`name` LIKE '%".$search."%')";
            $result_keyword = mysqli_query($con,$research_query_keyword);
            $s_no=1;
            while($row=mysqli_fetch_assoc($result_keyword))
            {
              ?>
              <tr>
              <td><?php echo $s_no; ?></td>
              <td><a href="faculty/upload/faculty/<?php echo $row['path'];?>" target="_blank"><?php echo $row['name']; ?></a></td>
              <td><?php echo $row['author']; ?></td>
              <td><?php echo $row['confrence']; ?></td>
              <td><?php echo $row['year']; ?></td>
              <td><?php echo $row['department']; ?></td>
              </tr>

        <?php
              $s_no++;
            }
        }
        ?>
        <?php
      if($by=='3')
        {   
            $research_query_keyword= "SELECT * FROM tbl_paper WHERE (`confrence` LIKE '%".$search."%')";
            $result_keyword = mysqli_query($con,$research_query_keyword);
            $s_no=1;
            while($row=mysqli_fetch_assoc($result_keyword))
            {
              ?>
              <tr>
              <td><?php echo $s_no; ?></td>
              <td><a href="faculty/upload/faculty/<?php echo $row['path']; ?>" target="_blank"><?php echo $row['name']; ?></a></td>
              <td><?php echo $row['author']; ?></td>
              <td><?php echo $row['confrence']; ?></td>
              <td><?php echo $row['year']; ?></td>
              <td><?php echo $row['department']; ?></td>
              </tr>

        <?php
              $s_no++;
            }
        }
        ?>

        <?php
        if($by=='4')
        {   
            $research_query_keyword= "SELECT * FROM tbl_paper WHERE (`year` LIKE '%".$search."%')";
            $result_keyword = mysqli_query($con,$research_query_keyword);
            $s_no=1;
            while($row=mysqli_fetch_assoc($result_keyword))
            {
              ?>
              <tr>
              <td><?php echo $s_no; ?></td>
              <td><a href="faculty/upload/faculty/<?php echo $row['path']; ?>" target="_blank"><?php echo $row['name']; ?></a></td>
              <td><?php echo $row['author']; ?></td>
              <td><?php echo $row['confrence']; ?></td>
              <td><?php echo $row['year']; ?></td>
              <td><?php echo $row['department']; ?></td>
              </tr>

        <?php
              $s_no++;
            }
        }
        ?>
        <?php
        if($by=='5')
        {   
            $research_query_keyword= "SELECT * FROM tbl_paper WHERE (`department` LIKE '%".$search."%')";
            $result_keyword = mysqli_query($con,$research_query_keyword);
            $s_no=1;
            while($row=mysqli_fetch_assoc($result_keyword))
            {
              ?>
              <tr>
              <td><?php echo $s_no; ?></td>
              <td><a href="faculty/upload/faculty/<?php echo $row['path']; ?>" target="_blank"><?php echo $row['name']; ?></a></td>
              <td><?php echo $row['author']; ?></td>
              <td><?php echo $row['confrence']; ?></td>
              <td><?php echo $row['year']; ?></td>
              <td><?php echo $row['department']; ?></td>
              </tr>

        <?php
              $s_no++;
            }
        }
        ?>
         <?php
        if($by=='6')
        {   
            $research_query_keyword= "SELECT * FROM tbl_faculty WHERE (`name` LIKE '%".$search."%')";
            $result_keyword = mysqli_query($con,$research_query_keyword);
            $s_no=1;
            while($row=mysqli_fetch_assoc($result_keyword))
            {
              ?>
              <tr>
              <td><?php echo $s_no; ?></td>
              <td><?php echo $row['name']; ?></td>
              <td><?php echo $row['department']; ?></td>
              <td><?php echo $row['email']; ?></td>
              <td><?php echo $row['degree']; ?></td>
              <td><?php echo $row['experience']; ?></td>
              <td><a href="view.php?user=<?php echo $row['fid'];?>">Profile</a></td>
              </tr>

        <?php
              $s_no++;
            }
        }
        ?>
     
   </tbody>
 </table>


   </div>

 	<div class="footer">
 			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
 	</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   </body>
 </html>
