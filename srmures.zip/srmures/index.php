<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SRMU RESEARCH PORTAL</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/foot.css">

    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,500" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Upright" rel="stylesheet">
    <link rel="stylesheet" href="css/loader.css"/>

    <!-- <script type='text/javascript'>
      if(history.replaceState) history.replaceState({}, "", "/srmures/");
      </script> -->

  </head>
    <body onload="myFunction()" id="demo" style="margin:0;background: #202340;">
    <div id="loader">
        <h1>SRMU Research and Placement Portal</h1>
        <div class="cube-wrapper">
            <div class="cube-folding">
                <span class="leaf1"></span>
                <span class="leaf2"></span>
                <span class="leaf3"></span>
                <span class="leaf4"></span>
              </div>
              <span class="loading" data-name="Loading">Loading</span>
        </div>

    <!-- follow me template -->
        <div class="made-with-love">
        Made with
        <i>LOVE</i> by
        <a target="_blank" href="https://srmu.ac.in">Z.A.A.J</a>
      </div>
    </div>

<div style="display:none;" id="myDiv">
    <div class="tnav">
       <div class="tnavtop">
           <a style="color:white;" href="../srmures/">
<img src="images/dp-logo.png" />
           <span>SRMU Research and Placement Portal</span>
</a>
           <a href="#" id="right" onclick="log()">Login / Sign Up</a>

       </div>
       <div id="log" style="display:none;">
         <span>Faculty</span>
         <a href="login">
         <button type="button">Login</button>
         </a>
         <br><br>

        <span>HR</span>
          <a href="login">
          <button type="button">Login</button>
          </a>
       </div>

       <div class="tnavdown">
         <div class="adark">
           <div class="dark">

           </div>
           <span>Quick Links:</span>
         </div>

         <div class="links">
         <a href="#">Placement Portal</a>
           <a href="https://srmu.ac.in">SRMU Website</a>
           <a href="login">HR Login</a>
           <a href="login">Faculties Login</a>
           <a href="#abt">Contact us</a>
         </div>
       </div>
    </div>
<div class="head">

</div>
<div class="middle">
  <span id="src">SEARCH RESEARCH PAPER </span>

  <div class="search">
    <form class="esearch" action="search" method="post">
      <select class="opt" name="by" required>
      <option value="" selected disabled>--Search By--</option>
        <option value="1">Keyword</option>
        <option value="2">Paper Name</option>
        <option value="3">Confrence</option>
        <option value="4">Year</option>
        <option value="5">By Department</option>
        <option value="6">By Faculty Name</option>
      </select>
    <input type="text" name="search" placeholder="Search Research Papers of Faculties"/>
    <input type="submit" name="submit" value="Search">
  </form>
  </div>
</div>
<div class="abt" id="abt">
  <section id="test" class="test bg-black roomy-60 fix">
    <div class="overlay"></div>
    <div class="container">
        <div class="row">
            <div class="main_test fix text-center">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="head_title text-center fix">
                        <h2 class="text-uppercase text-white">About Us</h2>
                        <h5 class="text-white">Welcome to SRMU RESEARCH AND PLACEMENT PORTAL. In this RESEARCH PORTAL you can easily find srmu faculties research paper and about the faculties specialization and area of Interest</h5>
                    </div>
                </div>

                <div id="testslid" class="carousel slide carousel-fade" data-ride="carousel">

                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="test_item fix">
                                    <div class="test_img fix">

                                    </div>

                                    <div class="test_text text-white">
                                        <em>    In our university there is a problem that most of the student don't know about
                                            the faculties and there area of interest, their achievement ,their specification and how
                                            many research paper published by them. And also faculties have to give these details yearly
                                            to the management even more than once and all the things done manually so a lot of time is wasted.
                                            So our RESEARCH PORTAL will solve this problem.</em>

                                    </div>
                                </div>
                            </div>
                        </div><!-- End off item -->

                        <div class="item">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="test_item fix">
                                    <div class="test_img fix">

                                    </div>

                                    <div class="test_text text-white">
                                        <em>In our PLACEMENT CELL,every student have to enter the job form day by day and sometimes they also miss <thead>
                                          job notice.so to solve this problem we created the PLACEMENT PORTAL.</em>

                                    </div>
                                </div>
                            </div>
                        </div><!-- End off item -->


                    </div><!-- End off carosel inner -->

                    <!-- Controls -->
                    <a class="left carousel-control" href="#testslid" role="button" data-slide="prev">
                        <i class="fa fa-angle-left" aria-hidden="true"></i>
                        <span class="sr-only">Previous</span>
                    </a>

                    <a class="right carousel-control" href="#testslid" role="button" data-slide="next">
                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                        <span class="sr-only">Next</span>
                    </a>

                </div>

            </div>
        </div><!-- End off row -->
    </div><!-- End off container -->
</section><!-- End off test section -->

</div>
<div class="footer">
    <p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/load.js"></script>
<script type="text/javascript">
  function log() {
    var div = document.getElementById('log');
        var status=div.style.display;
        if(status=="none")
        {
          div.style.display="block";
        }
        else
        {
          div.style.display="none";
        }
  }
</script>
  </body>
</html>
