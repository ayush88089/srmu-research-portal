<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Error</title>
    <link rel="stylesheet" href="/srmures/css/nav.css" type="text/css">
    <link rel="stylesheet" href="/srmures/css/index.css" type="text/css">
    <link rel="stylesheet" href="/srmures/css/foot.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,500" rel="stylesheet">

  </head>
    <body    style="margin:0;">

<div id="myDiv">
    <div class="tnav">
       <div class="tnavtop">
           <a style="color:white;" href="/srmures/">
<img src="/srmures/images/dp-logo.png" />
           <span>SRMU Research and Placement Portal</span>
         </a>

           <a href="#" id="right" onclick="log()">Login / Sign Up</a>

       </div>
       <div id="log" style="display:none;">
         <span>Faculty</span>
         <a href="/srmures/login">
         <button type="button">Login</button>
         </a>
         <br><br>

        <span>HR</span>
          <a href="login">
          <button type="button">Login</button>
          </a>
       </div>

       <div class="tnavdown">
         <div class="adark">
           <div class="dark">

           </div>
           <span>Quick Links:</span>
         </div>

         <div class="links">
         <a href="#">Placement Portal</a>
           <a href="https://srmu.ac.in">SRMU Website</a>
           <a href="/srmures/login">HR Login</a>
           <a href="/srmures/login">Faculties Login</a>
           <a href="/srmures/#abt">Contact us</a>
         </div>
       </div>
    </div>

<div class="error">
<p style="color:#2d6596;text-align:center;">
  Aa-oh , Look likes<br> you are RESEARCHING with URL !!
</p>

</div>

<div class="footer">
    <p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
</div>
</div>

  </body>
</html>
