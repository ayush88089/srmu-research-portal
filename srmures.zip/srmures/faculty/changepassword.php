<?php
session_start();
require('../dbconfig/config.php');

extract($_POST);
$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
$fid=$_SESSION['faculty'];
$password_query="SELECT password FROM tbl_faculty WHERE email='$fid'";
$res=mysqli_query($con,$password_query);
while($row=mysqli_fetch_assoc($res))
{   $a=$row['password'];
    if($a==$opass)
    {
        if($npass==$cpass)
        {
            $password_update = "UPDATE `tbl_faculty` SET `password`='$npass' WHERE `email`='$fid'";
            $run=mysqli_query($con,$password_update);
            if($run)
            header('Location:change?change=1');
            else header('Location:change?change=3');
        }
        else header('Location:change?change=2');
    }
    else header('Location:change?change=4');
}
?>