<?php
extract($_POST);
session_start();
require('../dbconfig/config.php');
$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

$email= $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
$a="select photo from tbl_faculty where email='$email'";
echo $a;
$res=mysqli_query($con,$a);
if($row=mysqli_fetch_assoc($res))
$path="../upload/faculty/".$row['photo'];
echo $path;
unlink($path);

$file=$_FILES['photo']['name'];
$file=md5($file);
$size=$_FILES['photo']['size'];
$type=$_FILES['photo']['type'];
$tmp_name=$_FILES['photo']['tmp_name'];
$location="../upload/faculty/";
$q="UPDATE `tbl_faculty` SET `photo`='$file' WHERE `email`='$email'";
echo $q;
if(mysqli_query($con,$q))
{
  move_uploaded_file($tmp_name,$location.$file);
  header("location:profile?msg=1");
}
else {
  header("location:profile?msg=2");
}


 ?>
