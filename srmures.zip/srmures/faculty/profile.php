<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

//echo $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <meta charset="utf-8">
    <title>Dashbored</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/index.css" type="text/css">
    <link rel="stylesheet" href="../css/form.css" type="text/css">
    <link rel="stylesheet" href="../css/nav.css" type="text/css">
		<link rel="stylesheet" href="../css/foot.css" type="text/css">
  </head>
  <body>

  <div class="tnav">
     <div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['faculty'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

         </div>
         <span>Quick Links:</span>
       </div>

       <div class="links">
				 <a href="home">Homepage</a>
         <a href="addpaper">Add Research</a>
         <a href="viewfaculty">View Profile</a>
         <a href="updateprofile">Update Profile</a>
         <a href="ownpapers">Your Paper</a>
         <a href="profile">Change Profile Photo</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>
       </div>
     </div>
  </div>

  <div class="content" style="margin-top:0px;width:95%;">
  <form class="form" action="updatephoto" method="post" enctype="multipart/form-data">
        <?php
        error_reporting(0);
        $msg=$_REQUEST['msg'];
        if($msg==1)
        {
          echo "<br><span>Update Successful !!</span><br>";
        }
        if($msg==2)
        {
          echo "<br><span>Error !!</span><br>";
        }
        $fid=$_SESSION['faculty'];
        $q="Select * from tbl_faculty where email='$fid'";
        $res=mysqli_query($con,$q);
        if($row=mysqli_fetch_array($res,MYSQL_BOTH))
        {
        ?>
        <br>
        <span> Current Profile Photo</span>
        <br>
        <img src="/srmures/upload/faculty/<?php echo $row['photo']?>" alt="current image" width="300px" height="300px" style="border-radius:50%">
        <input type="file" name="photo" class="in" required/>
        <input style="cursor:pointer;" type="submit" name="submit" value="Update">
        <?php
        }
        ?>
      </form>

  </div>
	<div class="footer">
			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
	</div>
    
  </body>
</html>
