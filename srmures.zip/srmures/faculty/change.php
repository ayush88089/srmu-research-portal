<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
$valid=$_REQUEST['change'];

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

//echo $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <meta charset="utf-8">
    <title>Dashbored</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="../css/dash.css"> -->
    <link rel="stylesheet" href="../css/index.css" type="text/css">
    <link rel="stylesheet" href="../css/form.css" type="text/css">
    <link rel="stylesheet" href="../css/nav.css" type="text/css">
		<link rel="stylesheet" href="../css/foot.css" type="text/css">
  </head>
  <body>

  <div class="tnav">
     <div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['faculty'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

         </div>
         <span>Quick Links:</span>
       </div>

       <div class="links">
       <a href="home">Homepage</a>
         <a href="addpaper">Add Research</a>
         <a href="viewfaculty">View Profile</a>
         <a href="updateprofile">Update Profile</a>
         <a href="ownpapers">Your Paper</a>
         <a href="profile">Change Profile Photo</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>
       </div>
     </div>
  </div>

  <div class="content" style="margin-top:0px;width:95%;">
    <form class="form" action="changepassword.php" method="post" >
      <?php
      if($valid==2)
      {
        echo "Password Doesn't Match";
      }
      if($valid==4)
      {
        echo "Wrong Password";
      }
      if($valid==3)
      {
        echo "Server Error";
      }
      if($valid==1)
      {
        echo "Password Change";
      }

      ?>
      <br>
      <h4>Change Password</h4><br>
      <input class="in" type="password" name="opass" placeholder="Enter Old Password" required /><br>
      <input class="in" type="password" name="npass" placeholder="Enter New Password" required/><br>
      <input class="in" type="password" name="cpass" placeholder="Enter Confirm Password" required/><br>      
      <input style="cursor:pointer;" type="submit" name="submit" value="Change">
    </form>
  </div>
	<div class="footer">
			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
	</div>
  </body>
</html>
