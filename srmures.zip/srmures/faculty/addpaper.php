<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
$valid=$_REQUEST['upload'];

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

//echo $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <meta charset="utf-8">
    <title>Dashbored</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="../css/dash.css"> -->
    <link rel="stylesheet" href="../css/index.css" type="text/css">
    <link rel="stylesheet" href="../css/form.css" type="text/css">
    <link rel="stylesheet" href="../css/nav.css" type="text/css">
		<link rel="stylesheet" href="../css/foot.css" type="text/css">
  </head>
  <body>

  <div class="tnav">
     <div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['faculty'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

         </div>
         <span>Quick Links:</span>
       </div>

       <div class="links">
       <a href="home">Homepage</a>
         <a href="addpaper">Add Research</a>
         <a href="viewfaculty">View Profile</a>
         <a href="updateprofile">Update Profile</a>
         <a href="ownpapers">Your Paper</a>
         <a href="profile">Change Profile Photo</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>
       </div>
     </div>
  </div>

  <div class="content" style="margin-top:0px;width:95%;">
    <form class="form" action="uploadpaper" method="post" enctype="multipart/form-data">
      <!-- <input type="hidden" name="MAX_FILE_SIZE" value="800000" /> -->
      <?php
      if($valid==2)
      {
        echo "Server Error!! Please try again or contact administrator !";
      }
      if($valid==1)
      {
        echo "Congrats! Paper Added!";
      }
      if($valid==3)
      {
        echo "File should be pdf,doc,docx format only!!!!";
      }

      ?>
      <br>
      <h4>Add Research Paper</h4><br>
      <input class="in" type="text" name="paper_name" placeholder="Enter Paper name" required /><br>
      <input class="in" type="text" name="author" placeholder="Author name" required/><br>
      <select class="dept" name="department" required>
          <option value="" selected disabled>--Select Department--</option>
          <option value="cse">CSE</option>
          <option value="civil">Civil</option>
          <option value="me">Mechanical</option>
          <option value="ece">ECE</option>
          <option value="ee">EE</option>
          <option value="bio">Biotechnology</option>
        </select><br>
      <input class="in" type="text" pattern="^\d{4}$" title="Enter valid year eg. YYYY" name="year" placeholder="year" required/><br>
      <span>Upload Your Paper:</span> <br>
      <input class="in" type="file" name="paper" required><br>
      <input class="in" type="text" name="confrence_name" placeholder="Enter Confrence name" required /><br>
      
      <input class="in" type="text" name="keyword" placeholder="Enter keyword" required /><br>
      <span>Example: Physics relativity sound</span><br>
      <textarea class="txt" id="int" name="abt" rows="8" cols="80" placeholder="About the paper" required></textarea>
      <br>
      <input style="cursor:pointer;" type="submit" name="submit" value="Add">
      
    </form>
  </div>
	<div class="footer">
			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
	</div>
  </body>
</html>
