<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
//$chng=$_REQUEST['chng'];
if($chng==1)
{
	echo "<script>alert('Password Changed!!');</script>";
}
$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

//echo $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <meta charset="utf-8">
    <title>Search Faculty</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/index.css" type="text/css">
    <link rel="stylesheet" href="../css/flip.css" type="text/css">
    <link rel="stylesheet" href="../css/nav.css" type="text/css">
		<link rel="stylesheet" href="../css/foot.css" type="text/css">
  </head>
  <body>

  <div class="tnav">
     <div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['faculty'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

         </div>
         <span>Quick Links:</span>
       </div>

       <div class="links">
       <a href="home">Homepage</a>
         <a href="addpaper">Add Research</a>
         <a href="viewfaculty">View Profile</a>
         <a href="updateprofile">Update Profile</a>
         <a href="ownpapers">Your Paper</a>
         <a href="profile">Change Profile Photo</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>


       </div>
     </div>
  </div>
  <div class="search" style="float: left;width: 100%;">
    <form class="esearch" action="search.php" method="post">

    <input type="text" name="search" placeholder="Search Faculties"/>
    <input type="submit" name="submit" value="Search">


  </form>
  </div>

	<div class="footer">
			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
	</div>

  </body>
</html>
