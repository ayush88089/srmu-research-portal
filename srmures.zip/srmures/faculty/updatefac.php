<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

$fid= $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
extract($_POST);
$query="UPDATE `tbl_faculty` SET `name`='$name',`experience`='$exp',`mobile`='$no',`aoi`='$special',`about`='$abt' WHERE `fid`='$fid'";
$run=mysqli_query($con,$query);
if($run)
header("Location:updateprofile?msg=1");
else header("Location:updateprofile?msg=2");
?>
