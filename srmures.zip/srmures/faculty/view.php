<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
//$chng=$_REQUEST['chng'];
if($chng==1)
{
	echo "<script>alert('Password Changed!!');</script>";
}
//echo $_SESSION['faculty'];
$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">


<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Profile</title>
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Upright" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/flip.css">
    <link rel="stylesheet" href="../css/nav.css">
		<link rel="stylesheet" href="../css/foot.css">

    <link rel="stylesheet" href="../css/viewfac.css">

  </head>
  <body>

  <div class="tnav">
     <div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['faculty'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

         </div>
         <span>Quick Links:</span>
       </div>

       <div class="links">
       <a href="home">Homepage</a>
         <a href="addpaper">Add Research</a>
         <a href="viewfaculty">View Profile</a>
         <a href="updateprofile">Update Profile</a>
         <a href="ownpapers">Your Paper</a>
         <a href="profile">Change Profile Photo</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>


       </div>
     </div>
  </div>



<br>
<div class="container bootstrap snippet">
    <div class="row">
  		<div class="col-sm-12" style="text-align:center;"><h1>Faculty Profile</h1></div>
      </div>
			<div class="row">
				<div class="col-sm-12">
					<hr>
				</div>
			</div>
			<?php
			require("../dbconfig/config.php");
			error_reporting(0);
      $a=$_REQUEST['user'];
			$q="Select * from tbl_faculty where fid='$a'";
			$p="Select * from tbl_paper where fid='$a'";
			$res=mysqli_query($con,$q);
			$resp=mysqli_query($con,$p);
			while($row=mysqli_fetch_assoc($res))
			{



			 ?>
    <div class="row">
  		<div class="col-sm-4"><!--left col-->


      <div class="text-center">
        <img src="../upload/faculty/<?php echo $row['photo']; ?>" class="avatar img-circle img-thumbnail" width="100" alt="avatar">
      </div><hr/><br>
        </div><!--/col-3-->

    	<div class="col-sm-8">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
                <li><a data-toggle="tab" href="#settings">Research Paper</a></li>
              </ul>


          <div class="tab-content">
            <div class="tab-pane active" id="home">
                <hr>
                  <form class="form" action="##" method="post" id="registrationForm">
                      <div class="form-group">

                          <div class="col-xs-6">
                              <label for="first_name"><h4>Name</h4></label>
                              <p style="color:#5a91c3;">
                                    <span class="detail"><?php echo $row['name']; ?></span>
                                </p>
                              </div>
                      </div>



                      <div class="form-group">

                          <div class="col-xs-6">
                              <label for="phone"><h4>Mobile</h4></label>
                              <p style="color:#5a91c3;">
                                    <span class="detail"><?php echo $row['mobile']; ?></span>
                                </p>
                              </div>
                      </div>


                      <div class="form-group">
												  <div class="col-xs-6">
                              <label for="email"><h4>Email</h4></label>
                              <p style="color:#5a91c3;">
                                <span id="detail">  <?php echo $row['email']; ?> </span>
                                </p>

                          </div>
                      </div>

											<div class="form-group">
												  <div class="col-xs-6">
                              <label for="department"><h4>Department</h4></label>
                              <p style="color:#5a91c3;">
                                <span class="detail">  <?php echo $row['department']; ?> </span>
                                </p>

                          </div>
                      </div>

											<div class="form-group">
												  <div class="col-xs-6">
                              <label for="degree"><h4>Degree</h4></label>
                              <p style="color:#5a91c3;">
                                <span class="detail">  <?php echo $row['degree']; ?> </span>
                                </p>

                          </div>
                      </div>
											<div class="form-group">
												  <div class="col-xs-6">
                              <label for="experience"><h4>Experience</h4></label>
                              <p style="color:#5a91c3;">
                                <span class="detail">  <?php echo $row['experience']; ?> </span>
                                </p>

                          </div>
                      </div>

											<div class="form-group">
												  <div class="col-xs-6">
                              <label for="aoi"><h4>Area of Interest</h4></label>
                              <p style="color:#5a91c3;">
                                <span class="detail">  <?php echo $row['aoi']; ?> </span>
                                </p>

                          </div>
                      </div>

											<div class="form-group">
												  <div class="col-xs-6">
                              <label for="about"><h4>About</h4></label>
                              <p style="color:#5a91c3;">
                                <span class="detail">  <?php echo $row['about']; ?> </span>
                                </p>

                          </div>
                      </div>

              	</form>
              <hr>


             </div><!--/tab-pane-->
						 <?php

               $fid =$row['fid'];
							$p="Select * from tbl_paper where fid='$fid'";
							$resp=mysqli_query($con,$p);



							?>

							<div class="tab-pane" id="settings">
              <table class="table table-responsive"> 
              <thead class="thead-light">
              <tr>
              <th>S.no</th>
              <th>Paper Name</th>
              <th>Author</th>
              <th>Conference</th>
              <th>Year</th>
              <th>About</th>
              </tr>
              </thead>
							<?php
							if(mysqli_num_rows($resp)==0)
							{echo "No paper";
							}
              else
              $s_no=1;
							while($rowp=mysqli_fetch_array($resp))
							{

						 ?>

              <tr>
              <th scope="col"><?php echo $s_no; ?></th>
              <th scope="col"><a href="upload/faculty/<?php echo $rowp['path']; ?>" target="_blank"><?php echo $rowp['name']; ?></a></th>
              <th scope="col"><?php echo $rowp['author']; ?></th>
              <th scope="col"><?php echo $rowp['confrence']; ?></th>
              <th scope="col"><?php echo $rowp['year']; ?></th>
              <th scope="col"><?php echo $rowp['about']; ?></th>
              </tr>
									
							<?php
                $s_no++;
								}
								?>

							</div>

              </div><!--/tab-pane-->
          </div><!--/tab-content-->


        </div><!--/col-9-->
    </div><!--/row-->
      <?php
      }
      ?>

	<div class="footer">
			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
	</div>
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </body>
</html>
