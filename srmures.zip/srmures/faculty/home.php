<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);
//$chng=$_REQUEST['chng'];
if($chng==1)
{
	echo "<script>alert('Password Changed!!');</script>";
}
$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

//echo $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <meta charset="utf-8">
    <title>Dashbored</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="../css/dash.css"> -->
    <link rel="stylesheet" href="../css/index.css" type="text/css">
    <link rel="stylesheet" href="../css/flip.css" type="text/css">
    <link rel="stylesheet" href="../css/nav.css" type="text/css">
		<link rel="stylesheet" href="../css/foot.css" type="text/css">
  </head>
  <body>

  <div class="tnav">
     <div class="tnavtop">
         <img src="../images/dp-logo.png" />
         <span>SRMU Research and Placement Portal</span>

         <a href="#" id="right"><?php echo $_SESSION['faculty'];?></a>

     </div>


     <div class="tnavdown">
       <div class="adark">
         <div class="dark">

         </div>
         <span>Quick Links:</span>
       </div>

       <div class="links">
       <a href="home">Homepage</a>
         <a href="addpaper">Add Research</a>
         <a href="viewfaculty">View Profile</a>
         <a href="updateprofile">Update Profile</a>
         <a href="ownpapers">Your Paper</a>
         <a href="profile">Change Profile Photo</a>
         <a href="change">Change Password</a>
         <a href="logout">Logout</a>
       </div>
     </div>
  </div>
  <div class="search">
    <form class="esearch" action="search.php" method="post">
      <select class="opt" name="by" required>
        <option value="" selected disabled>--Search By--</option>
        <option value="1">Keyword</option>
        <option value="2">Paper Name</option>
        <option value="3">Confrence</option>
        <option value="4">Year</option>
        <option value="5">By Department</option>
        <option value="6">By Faculty Name</option>

      </select>
    <input type="text" name="search" placeholder="Search Research Papers of Faculties" required/>
    <input type="submit" name="submit" value="Search">
  </form>
  </div>
  <div class="content">
		<div class="card">
          <div class="imgbox">
              <img src="../images/view.png" alt="">
          </div>
          <div class="details">
              <a href="viewfaculty">VIEW PROFILE</a>
          </div>
    </div>
		
    <div class="card">
          <div class="imgbox">
              <img src="../images/p.png"  alt="">
          </div>
          <div class="details">
              <a href="addpaper">ADD PAPER</a>
          </div>
    </div>
		<div class="card">
          <div class="imgbox">
              <img src="../images/leave.png"  alt="">
          </div>
          <div class="details">
              <a href="ownpapers.php">YOUR PAPERS</a>
          </div>
    </div>
    <div class="card">
          <div class="imgbox">
              <img src="../images/change.png"  alt="">
          </div>
          <div class="details">
              <a href="change">CHANGE PASSWORD</a>
          </div>
    </div>

    <div class="card">
           <div class="imgbox">
              <img src="../images/logout.png"  alt="">
           </div>
           <div class="details">
              <a href="logout">LOGOUT</a>
          </div>
    </div>
  </div>
	<div class="footer">
			<p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
	</div>
  </body>
</html>
