<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
$id=$_REQUEST['id'];
$path=$_REQUEST['path'];
echo $path;
$query="delete from tbl_paper where paper_id='$id'";
mysqli_query($con,$query);
unlink($path);
header("Location:ownpapers.php");
echo $query;
?>