<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

//echo $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Error</title>
    <link rel="stylesheet" href="/srmures/css/nav.css" type="text/css">
    <link rel="stylesheet" href="/srmures/css/index.css" type="text/css">
    <link rel="stylesheet" href="/srmures/css/foot.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,500" rel="stylesheet">

  </head>
    <body    style="margin:0;">

<div id="myDiv">
    <div class="tnav">
       <div class="tnavtop">
           <a style="color:white;" href="/srmures/">
<img src="/srmures/images/dp-logo.png" />
           <span>SRMU Research and Placement Portal</span>
         </a>

         <a href="#" id="right"><?php echo $_SESSION['faculty'];?></a>

       </div>
       <div id="log" style="display:none;">
         <span>Faculty</span>
         <a href="/srmures/login">
         <button type="button">Login</button>
         </a>
         <br><br>

        <span>HR</span>
          <a href="login">
          <button type="button">Login</button>
          </a>
       </div>

       <div class="tnavdown">
         <div class="adark">
           <div class="dark">

           </div>
           <span>Quick Links:</span>
         </div>

         <div class="links">
         <a href="/srmures/faculty/home">Homepage</a>
         <a href="/srmures/faculty/addpaper">Add Research</a>
         <a href="/srmures/faculty/viewfaculty">View Profile</a>
         <a href="/srmures/faculty/updateprofile">Update Profile</a>
         <a href="/srmures/faculty/ownpapers">Your Paper</a>
         <a href="/srmures/faculty/profile">Change Profile Photo</a>
         <a href="/srmures/faculty/change">Change Password</a>
         <a href="/srmures/faculty/logout">Logout</a>
         </div>
       </div>
    </div>

<div class="error">
<p style="color:#2d6596;text-align:center;">
  Aa-oh , Look likes<br> you are RESEARCHING with URL !!
</p>

</div>

<div class="footer">
    <p id="foot">Designed by Ankita,Ayush,Jagmohan,Zeeshan</p>
</div>
</div>

  </body>
</html>
