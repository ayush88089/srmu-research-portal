<?php
session_start();
require('../dbconfig/config.php');
error_reporting(0);

$now=time();
if($now>$_SESSION['expire'])
{
  session_destroy();
  header("location:../login?id=2");
}

//echo $_SESSION['faculty'];
if($_SESSION['faculty']=="")
{
	session_destroy();
	header("location:../login?id=2");
}

extract($_POST);
$mail= $_SESSION['faculty'];
$a="select fid from tbl_faculty where email='$mail'";
$res=mysqli_query($con,$a);
if($row=mysqli_fetch_assoc($res))
{
  $faculty_id=$row[fid];

  $file=$_FILES['paper']['name'];
  $file=md5($file);
  //echo $file;
  $size=$_FILES['paper']['size'];
  //echo $size;
  
  $type=$_FILES['paper']['type'];
//  echo $type;
  $tmp_name=$_FILES['paper']['tmp_name'];
//  echo $tmp_name;
  $location="upload/faculty/";
  
  if (($_FILES["paper"]["type"] == "application/pdf") || ($_FILES["paper"]["type"] == "application/msword") || ($_FILES["paper"]["type"] == "application/vnd.openxmlformats-officedocument.wordprocessingml.document") && ($_FILES["paper"]["size"] < 20000000) && in_array($extension, $allowedExts))
  {
  $q="INSERT INTO `devpoint`.`tbl_paper` (`name`,`fid`,`author`, `path`, `confrence`, `about`,`year`,`keyword`,`department`) VALUES ('$paper_name','$faculty_id', '$author', '$file', '$confrence_name', '$abt','$year','$keyword','$department')";
  echo $q;

if(mysqli_query($con,$q))
{
  move_uploaded_file($tmp_name,$location.$file);
  header("location:addpaper?upload=1");
}
else {
  header("location:addpaper?upload=2");
}
  }
  else 
  header("location:addpaper?upload=3");
}

?>
